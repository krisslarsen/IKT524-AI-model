
"""
util_dataset_helper_functions.py
Utilities for IKT524 YOLO project: dataset discovery, download, and preparation.

This module is designed to be imported by a *clean* runner notebook (e.g. setup_datasets.ipynb).
It exposes a small, stable API:
  - read_datasets_json() -> (Path, dict)
  - list_datasets(cfg: dict) -> list[str]
  - train_dataset_select(cfg: dict, name: str) -> dict
  - util_download_datasets(entry: dict) -> Path
  - prepare_dataset(entry: dict, raw_root: Path, prep_root: Path) -> dict

And format-specific helpers:
  - is_food101_root(path: Path) -> bool
  - prepare_food101_for_yolo_cls(food101_root: Path, out_root: Path) -> dict
  - detect_yolo_detection_layout(root: Path) -> dict | None
  - prepare_yolo_detection_passthrough(raw_root: Path, out_root: Path, entry: dict) -> dict

Notes:
- We favor **symlinks** for speed and space. If symlinks fail (Windows / permissions),
  we fall back to hardlinks or copies.
- For detection datasets already in YOLO layout, we mostly **pass through**:
  create a minimal `data.yaml` if missing, and standardize the output folder.
"""

from __future__ import annotations

import os
import json
import shutil
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple, Iterable, Set

# ---- Optional dependencies ---------------------------------------------------
try:
    from tqdm import tqdm  # type: ignore
except Exception:
    tqdm = None  # progress bars optional

try:
    import yaml  # type: ignore
except Exception:
    yaml = None  # will raise at write-time if needed

try:
    import kagglehub  # type: ignore
except Exception:
    kagglehub = None  # optional, only used when source == "kagglehub"


# ---- Global paths / config ---------------------------------------------------
HOME = Path.home()
DATASETS_DIR = Path(os.environ.get("IKT524_DATASETS_DIR", HOME / "datasets")).expanduser()
PREP_DIR = DATASETS_DIR

DATASETS_JSON_CANDIDATES = [
    Path.cwd() / "datasets.json",
    DATASETS_DIR / "datasets.json",
    HOME / "datasets" / "datasets.json",
]


# ---- Small utilities ---------------------------------------------------------
def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def symlink_or_copy(src: Path, dst: Path) -> None:
    """Create a symlink if possible; otherwise hardlink/copy the file."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        if dst.exists() or dst.is_symlink():
            dst.unlink()
    except Exception:
        pass

    try:
        os.symlink(src, dst)
        return
    except (OSError, NotImplementedError, AttributeError):
        # Try hardlink (same filesystem)
        try:
            os.link(src, dst)
            return
        except Exception:
            shutil.copy2(src, dst)


def write_yaml(path: Path, data: Dict[str, Any]) -> None:
    if yaml is None:
        raise RuntimeError("pyyaml not installed. In a notebook, run: %pip install pyyaml")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)


# ---- datasets.json helpers ---------------------------------------------------
def _write_template_datasets_json(path: Path) -> None:
    template = {
        "datasets": [
            {
                "name": "food-101",
                "kind": "classification",
                "source": "local",   # or "kagglehub"
                "ref": "dansbecker/food-101",
                "path": str(DATASETS_DIR / "food-101"),
                "format": "food101"
            },
            {
                "name": "my-yolo-detection",
                "kind": "detection",
                "source": "local",
                "path": str(DATASETS_DIR / "my-yolo-detection"),
                "format": "yolo",
                # Optional: provide class names if no data.yaml is present in the raw dataset
                # "names": ["class0", "class1"]
            }
        ]
    }
    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as f:
        json.dump(template, f, indent=2)


def read_datasets_json() -> Tuple[Path, Dict[str, Any]]:
    """Load datasets.json from common locations. If missing, write a helpful template."""
    for cand in DATASETS_JSON_CANDIDATES:
        if cand.exists():
            with cand.open("r", encoding="utf-8") as f:
                data = json.load(f)
            return cand, data
    # Not found -> create template at default
    tmpl = DATASETS_DIR / "datasets.json"
    _write_template_datasets_json(tmpl)
    with tmpl.open("r", encoding="utf-8") as f:
        data = json.load(f)
    return tmpl, data


def list_datasets(cfg: Dict[str, Any]) -> List[str]:
    return [d.get("name", "unnamed") for d in cfg.get("datasets", [])]


def train_dataset_select(cfg: Dict[str, Any], name: str) -> Dict[str, Any]:
    for d in cfg.get("datasets", []):
        if d.get("name") == name:
            return d
    raise KeyError(f"Dataset named '{name}' not found in datasets.json")


# ---- KaggleHub helpers -------------------------------------------------------
def kagglehub_download(ref: str) -> Path:
    if kagglehub is None:
        raise RuntimeError("kagglehub is not installed. In a notebook, run: %pip install kagglehub")
    print(f"[kagglehub] Downloading: {ref}")
    p = kagglehub.dataset_download(ref)
    if p is None:
        raise RuntimeError("kagglehub returned None (no path). Check the ref or auth.")
    return Path(p)


def mirror_to_target(src: Path, dst: Path) -> Path:
    """Mirror src directory into dst (copytree w/ dirs_exist_ok)."""
    src = Path(src).resolve()
    dst = Path(dst).resolve()
    if dst.exists() and any(dst.iterdir()):
        print(f"[mirror] Target already exists, skipping copy: {dst}")
        return dst
    print(f"[mirror] Copying\n  {src}\n-> {dst}")
    ensure_dir(dst.parent)
    shutil.copytree(src, dst, dirs_exist_ok=True)
    return dst


def util_download_datasets(entry: Dict[str, Any]) -> Path:
    """
    Ensure raw dataset is available locally and return its root path.
    Supports:
      - source == "local": use 'path'
      - source == "kagglehub": use 'ref' and mirror cache into DATASETS_DIR/<name>
    """
    name = entry.get("name", "dataset")
    source = entry.get("source", "local")

    if source == "local":
        p = Path(entry.get("path", ""))
        if not p.exists():
            raise FileNotFoundError(f"[{name}] Local path does not exist: {p}")
        print(f"[{name}] Using local dataset at: {p}")
        return p

    if source == "kagglehub":
        ref = entry.get("ref")
        if not ref:
            raise ValueError(f"[{name}] 'ref' required when source='kagglehub'")
        cache_dir = kagglehub_download(ref)
        target = DATASETS_DIR / name
        return mirror_to_target(cache_dir, target)

    raise ValueError(f"[{name}] Unsupported source: {source}")


# ---- Food-101 (classification) ----------------------------------------------
def is_food101_root(path: Path) -> bool:
    """
    Heuristic: Food-101 has 'images' and 'meta' folders, with 'classes.txt', 'train.txt', 'test.txt' in meta.
    """
    path = Path(path)
    images = path / "images"
    meta = path / "meta"
    req_files = ["classes.txt", "train.txt", "test.txt"]
    return images.is_dir() and meta.is_dir() and all((meta / f).exists() for f in req_files)


def _read_lines(p: Path) -> List[str]:
    with p.open("r", encoding="utf-8") as f:
        return [ln.strip() for ln in f if ln.strip()]


def _safe_stem_to_jpg(stem: str) -> str:
    return stem + ".jpg"


def prepare_food101_for_yolo_cls(food101_root: Path, out_root: Path) -> Dict[str, Any]:
    """
    Prepare Food-101 into a YOLO classification layout using symlinks:

      out_root/
        train/<class>/*.jpg
        val/<class>/*.jpg

    Uses meta/train.txt (-> train) and meta/test.txt (-> val).
    Returns a summary dict.
    """
    food101_root = Path(food101_root).resolve()
    images = food101_root / "images"
    meta = food101_root / "meta"
    assert images.is_dir(), f"Missing images folder: {images}"
    assert meta.is_dir(), f"Missing meta folder: {meta}"

    classes = _read_lines(meta / "classes.txt")
    train_list = _read_lines(meta / "train.txt")
    test_list  = _read_lines(meta / "test.txt")  # used as val

    out_root = Path(out_root).resolve()
    train_dir = out_root / "train"
    val_dir   = out_root / "val"
    ensure_dir(train_dir)
    ensure_dir(val_dir)

    # Link train
    train_cnt = 0
    iterator = tqdm(train_list, desc="Linking train") if tqdm else train_list
    for stem in iterator:
        cls, img_stem = stem.split("/")
        src = images / cls / _safe_stem_to_jpg(img_stem)
        dst = train_dir / cls / src.name
        if not src.exists():
            candidates = list((images / cls).glob(img_stem + ".*"))
            if not candidates:
                raise FileNotFoundError(f"Image not found for stem: {stem}")
            src = candidates[0]
            dst = train_dir / cls / src.name
        symlink_or_copy(src, dst)
        train_cnt += 1

    # Link val
    val_cnt = 0
    iterator = tqdm(test_list, desc="Linking val") if tqdm else test_list
    for stem in iterator:
        cls, img_stem = stem.split("/")
        src = images / cls / _safe_stem_to_jpg(img_stem)
        dst = val_dir / cls / src.name
        if not src.exists():
            candidates = list((images / cls).glob(img_stem + ".*"))
            if not candidates:
                raise FileNotFoundError(f"Image not found for stem: {stem}")
            src = candidates[0]
            dst = val_dir / cls / src.name
        symlink_or_copy(src, dst)
        val_cnt += 1

    # Optional YAML for classification
    yaml_path = out_root / "food101.yaml"
    yaml_data = {
        "task": "classify",
        "names": classes,
        "train": str(train_dir),
        "val":   str(val_dir),
    }
    write_yaml(yaml_path, yaml_data)

    return {
        "task": "classify",
        "classes": classes,
        "train_count": train_cnt,
        "val_count": val_cnt,
        "train_dir": str(train_dir),
        "val_dir": str(val_dir),
        "yaml": str(yaml_path),
    }


# ---- YOLO detection (pass-through / standardize) ----------------------------
_IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def _count_files(folder: Path, exts: Set[str]) -> int:
    if not folder or not folder.exists():
        return 0
    return sum(1 for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in exts)


def detect_yolo_detection_layout(root: Path) -> Optional[Dict[str, Path]]:
    """
    Try to detect a YOLO detection dataset layout.
    Two common patterns are supported:
      A) <root>/images/{train,val,test} and <root>/labels/{train,val,test}
      B) <root>/{train,val,test}/images and <root>/{train,val,test}/labels
    Returns a dict with normalized paths or None if not detected.
    """
    root = Path(root)

    # Pattern A
    a_images = root / "images"
    a_labels = root / "labels"
    if a_images.is_dir() and a_labels.is_dir():
        out = {"root": root}
        for split in ("train", "val", "test"):
            img = a_images / split
            lab = a_labels / split
            if img.exists():
                out[f"images_{split}"] = img
            if lab.exists():
                out[f"labels_{split}"] = lab
        if any(k.startswith("images_") for k in out):
            return out

    # Pattern B
    pattern_b_hits = {}
    for split in ("train", "val", "test"):
        split_dir = root / split
        if split_dir.is_dir():
            img = split_dir / "images"
            lab = split_dir / "labels"
            if img.is_dir():
                pattern_b_hits[f"images_{split}"] = img
            if lab.is_dir():
                pattern_b_hits[f"labels_{split}"] = lab
    if pattern_b_hits:
        pattern_b_hits["root"] = root
        return pattern_b_hits

    return None


def _scan_label_class_ids(labels_dir: Path) -> Set[int]:
    """Scan YOLO .txt label files for class IDs (first column per line)."""
    ids: Set[int] = set()
    if not labels_dir or not labels_dir.exists():
        return ids
    for p in labels_dir.rglob("*.txt"):
        try:
            with p.open("r", encoding="utf-8") as f:
                for ln in f:
                    ln = ln.strip()
                    if not ln:
                        continue
                    # class_id cx cy w h [extra...]
                    parts = ln.split()
                    try:
                        cls_id = int(float(parts[0]))
                        ids.add(cls_id)
                    except Exception:
                        continue
        except Exception:
            continue
    return ids


def _infer_names_from_labels(layout: Dict[str, Path], fallback: Optional[List[str]]) -> List[str]:
    if fallback:
        return list(fallback)
    ids: Set[int] = set()
    for split in ("train", "val", "test"):
        lab = layout.get(f"labels_{split}")
        ids |= _scan_label_class_ids(lab) if lab else set()
    if not ids:
        # default to a single class '0' if nothing found
        return ["0"]
    max_id = max(ids)
    # names list must be contiguous indices
    names = [str(i) for i in range(max_id + 1)]
    return names


def prepare_yolo_detection_passthrough(raw_root: Path, out_root: Path, entry: Dict[str, Any]) -> Dict[str, Any]:
    """
    Standardize a YOLO detection dataset into out_root and ensure a usable data.yaml.
    If the dataset already has the right layout, we symlink (or copy) into out_root.
    """
    raw_root = Path(raw_root).resolve()
    out_root = Path(out_root).resolve()
    ensure_dir(out_root)

    layout = detect_yolo_detection_layout(raw_root)
    if not layout:
        raise ValueError(f"Could not detect YOLO detection layout under: {raw_root}")

    # Create normalized structure under out_root/images/* and out_root/labels/*
    images_dir = out_root / "images"
    labels_dir = out_root / "labels"
    ensure_dir(images_dir); ensure_dir(labels_dir)

    summary = {"task": "detect"}

    for split in ("train", "val", "test"):
        src_img = layout.get(f"images_{split}")
        src_lab = layout.get(f"labels_{split}")
        if src_img and src_img.exists():
            # mirror by symlinking individual files to keep it robust across FS
            for img_path in src_img.rglob("*"):
                if img_path.is_file() and img_path.suffix.lower() in _IMG_EXTS:
                    rel = img_path.relative_to(src_img)
                    dst = images_dir / split / rel
                    symlink_or_copy(img_path, dst)
            summary[f"images_{split}_count"] = _count_files(images_dir / split, _IMG_EXTS)
        if src_lab and src_lab.exists():
            for lbl_path in src_lab.rglob("*.txt"):
                rel = lbl_path.relative_to(src_lab)
                dst = labels_dir / split / rel
                symlink_or_copy(lbl_path, dst)
            summary[f"labels_{split}_count"] = _count_files(labels_dir / split, {".txt"})

    # data.yaml
    yaml_path = out_root / "data.yaml"
    # If raw_root has a data.yaml, prefer to copy it but rewrite its 'path' to out_root
    raw_yaml = raw_root / "data.yaml"
    names_fallback = entry.get("names")
    if raw_yaml.exists():
        try:
            with raw_yaml.open("r", encoding="utf-8") as f:
                data = yaml.safe_load(f) if yaml else None
        except Exception:
            data = None
        if isinstance(data, dict):
            data["path"] = str(out_root)
            # Normalize relative locations
            data["train"] = "images/train" if (images_dir / "train").exists() else data.get("train", "")
            data["val"]   = "images/val"   if (images_dir / "val").exists() else data.get("val", "")
            if (images_dir / "test").exists():
                data["test"] = "images/test"
            if "names" not in data or not data["names"]:
                data["names"] = _infer_names_from_labels(layout, names_fallback)
            write_yaml(yaml_path, data)
        else:
            # Could not parse -> write minimal
            names = _infer_names_from_labels(layout, names_fallback)
            data = {
                "path": str(out_root),
                "train": "images/train" if (images_dir / "train").exists() else "",
                "val":   "images/val"   if (images_dir / "val").exists() else "",
                "test":  "images/test"  if (images_dir / "test").exists() else "",
                "names": names,
            }
            write_yaml(yaml_path, data)
    else:
        names = _infer_names_from_labels(layout, names_fallback)
        data = {
            "path": str(out_root),
            "train": "images/train" if (images_dir / "train").exists() else "",
            "val":   "images/val"   if (images_dir / "val").exists() else "",
            "test":  "images/test"  if (images_dir / "test").exists() else "",
            "names": names,
        }
        write_yaml(yaml_path, data)

    summary["yaml"] = str(yaml_path)
    summary["out_root"] = str(out_root)
    return summary


# ---- Orchestrator ------------------------------------------------------------
def prepare_dataset(entry: Dict[str, Any], raw_root: Path, prep_root: Path) -> Dict[str, Any]:
    """
    Generic entry point used by the clean notebook.
    Routes to a specific handler based on 'format' and/or structure detection.
    """
    fmt = str(entry.get("format", "")).lower().strip()
    kind = str(entry.get("kind", "")).lower().strip()

    # Classification: Food-101
    if fmt == "food101" or is_food101_root(raw_root):
        print("[prepare_dataset] Using Food-101 classification handler.")
        return prepare_food101_for_yolo_cls(raw_root, prep_root)

    # YOLO detection (already in YOLO layout)
    if fmt == "yolo" or detect_yolo_detection_layout(raw_root):
        print("[prepare_dataset] Using YOLO detection pass-through handler.")
        return prepare_yolo_detection_passthrough(raw_root, prep_root, entry)

    # Future: add more formats (e.g., COCO-to-YOLO conversion, segmentation, etc.)
    raise NotImplementedError(
        f"No handler for dataset format '{fmt}' (kind='{kind}'). "
        "Provide a suitable 'format' or implement a new prepare_<format>() and update prepare_dataset()."
    )


__all__ = [
    # small utils
    "ensure_dir", "symlink_or_copy", "write_yaml",
    # datasets.json
    "read_datasets_json", "list_datasets", "train_dataset_select",
    # download
    "util_download_datasets", "kagglehub_download", "mirror_to_target",
    # classification
    "is_food101_root", "prepare_food101_for_yolo_cls",
    # detection
    "detect_yolo_detection_layout", "prepare_yolo_detection_passthrough",
    # orchestrator
    "prepare_dataset",
]
