# util_helper_functions.py
import os
import requests
from ultralytics import YOLO

def util_test_model(
    model_filename="yolo11n.pt",
    test_image_name="Banana-Single.jpg",
    test_image_path=None,   # optional absolute override, e.g. "/home/kristoffel/utilities/util_test_images/Banana-Single.jpg"
):
    """
    Simple end-to-end YOLO model test:
      - Ensures model weights exist (downloads if needed)
      - Runs inference on a test image
      - Returns: '✅ Model test successful, image identified as: ...'
    """

    # --- Resolve paths relative to this file ---
    script_dir   = os.path.dirname(os.path.abspath(__file__))                 # .../utilities/util_functions
    project_root = os.path.abspath(os.path.join(script_dir, "..", ".."))      # typically .../<project-root> or .../utilities
    utilities_dir = os.path.abspath(os.path.join(script_dir, ".."))           # .../utilities

    # --- Ensure model weights exist under <project_root>/models ---
    models_folder = os.path.join(project_root, "models")
    os.makedirs(models_folder, exist_ok=True)
    model_path = os.path.join(models_folder, model_filename)

    if not os.path.isfile(model_path):
        url = f"https://github.com/ultralytics/assets/releases/download/v8.3.0/{model_filename}"
        print(f"⬇️ Downloading {model_filename}...")
        r = requests.get(url, stream=True)
        r.raise_for_status()
        with open(model_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f"✅ Saved to {model_path}")
    else:
        print(f"✅ Found local weight: {model_path}")

    # --- Resolve test image path ---
    if test_image_path:
        # Use caller-provided absolute path as-is
        if not os.path.isabs(test_image_path):
            raise ValueError("test_image_path must be an absolute path.")
        candidates = [test_image_path]
    else:
        # 1) images beside 'utilities' (one level up from this file) -> .../utilities/util_test_images/<name>
        candidate1 = os.path.join(utilities_dir, "util_test_images", test_image_name)
        # 2) images under project_root (two levels up) -> .../<project_root>/util_test_images/<name>
        candidate2 = os.path.join(project_root, "util_test_images", test_image_name)
        candidates = [candidate1, candidate2]

    test_image_resolved = next((p for p in candidates if os.path.isfile(p)), None)
    if not test_image_resolved:
        tried = "\n  - " + "\n  - ".join(candidates)
        raise FileNotFoundError(f"❌ Test image not found. Tried:{tried}")

    print(f"🖼️ Using test image: {test_image_resolved}")

    # --- Run inference ---
    model = YOLO(model_path)
    results = model(test_image_resolved)

    # --- Extract prediction labels ---
    names = model.names  # class ID → label
    detections = results[0].boxes.cls.tolist() if results and results[0].boxes is not None else []

    if not detections:
        message = "⚠️ No objects detected."
    else:
        labels = {names[int(cls_id)] for cls_id in detections}  # unique
        message = f"✅ Model test successful, image identified as: {', '.join(sorted(labels))}"

    print(message)
    return message
