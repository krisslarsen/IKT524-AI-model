# util_helper_functions.py
import os
import requests
from ultralytics import YOLO
from pathlib import Path
import json
from typing import Any, Dict, List

def util_test_basemodel(
    model_filename="yolo11n.pt",
    test_image_name="Banana-Single.jpg",
    test_image_path=None,     # absolute override
    show=False,               # display annotated image inline
    save=False,               # NEW: save annotated image to disk
    save_dir=None,            # NEW: where to save (defaults to <project_root>/results)
    save_name=None,           # NEW: custom filename (defaults to "<stem>__annotated.png")
):
    """
    Simple end-to-end YOLO model test:
      - Ensures model weights exist (downloads if needed)
      - Runs inference on a test image
      - Optionally displays/saves the detection result
      - Returns: '✅ Model test successful, image identified as: ...'
    """
    import matplotlib.pyplot as plt
    from PIL import Image
    import cv2
    import os

    # --- Resolve paths relative to this file ---
    script_dir    = os.path.dirname(os.path.abspath(__file__))                 # .../utilities/util_functions
    project_root  = os.path.abspath(os.path.join(script_dir, "..", ".."))      # typically .../<project-root> or .../utilities
    utilities_dir = os.path.abspath(os.path.join(script_dir, ".."))            # .../utilities

    # --- Ensure model weights exist ---
    models_folder = os.path.join(project_root, "models")
    os.makedirs(models_folder, exist_ok=True)
    model_path = os.path.join(models_folder, model_filename)

    if not os.path.isfile(model_path):
        url = f"https://github.com/ultralytics/assets/releases/download/v8.3.0/{model_filename}"
        print(f"⬇️ Downloading {model_filename}...")
        r = requests.get(url, stream=True)
        r.raise_for_status()
        with open(model_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f"✅ Saved to {model_path}")
    else:
        print(f"✅ Found local weight: {model_path}")

    # --- Resolve test image path ---
    if test_image_path:
        if not os.path.isabs(test_image_path):
            raise ValueError("test_image_path must be an absolute path.")
        candidates = [test_image_path]
    else:
        candidate1 = os.path.join(utilities_dir, "util_test_images", test_image_name)
        candidate2 = os.path.join(project_root, "util_test_images", test_image_name)
        candidates = [candidate1, candidate2]

    test_image_resolved = next((p for p in candidates if os.path.isfile(p)), None)
    if not test_image_resolved:
        tried = "\n  - " + "\n  - ".join(candidates)
        raise FileNotFoundError(f"❌ Test image not found. Tried:{tried}")

    print(f"🖼️ Using test image: {test_image_resolved}")

    # --- Run inference ---
    model = YOLO(model_path)
    results = model(test_image_resolved)

    # --- Extract prediction labels ---
    names = model.names
    detections = results[0].boxes.cls.tolist() if results and results[0].boxes is not None else []

    if not detections:
        message = "⚠️ No objects detected."
    else:
        labels = {names[int(cls_id)] for cls_id in detections}
        message = f"✅ Model test successful, image identified as: {', '.join(sorted(labels))}"

    print(message)

    # --- Optional display/save (convert BGR -> RGB first) ---
    if show or save:
        bgr = results[0].plot()                    # Ultralytics returns BGR
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB) # fix blue tint

        if show:
            plt.figure(figsize=(8, 6))
            plt.imshow(rgb)
            plt.axis("off")
            plt.title("Detection Result")
            plt.show()

        if save:
            # decide save dir/name
            out_dir = save_dir or os.path.join(project_root, "results")
            os.makedirs(out_dir, exist_ok=True)
            if save_name:
                out_name = save_name
            else:
                stem = os.path.splitext(os.path.basename(test_image_resolved))[0]
                out_name = f"{stem}__annotated.png"
            out_path = os.path.join(out_dir, out_name)

            # save in RGB (PIL handles it)
            Image.fromarray(rgb).save(out_path)
            print(f"💾 Saved annotated image to: {out_path}")

    return message




def util_find_existing_model(
    search_name=None,
    folder=None,
    extension=(".pt",),     # can be str or tuple, e.g. (".pt", ".onnx")
    return_all=False,       # if True, return a list of all matches (ordered by best score)
):
    """
    Find a model file in the models folder with smart matching.

    Matching priority:
      1) Exact filename (with or without extension), case-insensitive
      2) Exact stem match (filename without extension)
      3) Startswith match on stem (prefers plain 'yolo11n' over 'yolo11n-seg')
      4) Substring match on stem

    Tie-breakers:
      - Prefer plain names (no extra suffix like -seg, -pose, -cls)
      - Shorter filename
      - Alphabetical

    Returns:
      str or list[str]: Absolute path(s) to the best match(es)

    Raises:
      FileNotFoundError if the folder or a match isn’t found.
    """
    import os

    # normalize extension to tuple
    if isinstance(extension, str):
        extension = (extension,)

    # locate models folder
    script_dir   = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.abspath(os.path.join(script_dir, "..", ".."))
    models_folder = folder or os.path.join(project_root, "models")

    if not os.path.isdir(models_folder):
        raise FileNotFoundError(f"❌ Models folder not found: {models_folder}")

    # collect model files
    files = [f for f in os.listdir(models_folder) if f.lower().endswith(tuple(e.lower() for e in extension))]
    if not files:
        raise FileNotFoundError(f"❌ No model files {extension} found in: {models_folder}")

    # if no search term, either return first or all
    if not search_name:
        paths = [os.path.join(models_folder, f) for f in sorted(files)]
        if return_all:
            return paths
        print(f"✅ Found model: {paths[0]}")
        return paths[0]

    # normalize search
    s = search_name.lower()
    s_noext = os.path.splitext(s)[0]

    candidates = []
    for f in files:
        fname = f
        stem, ext = os.path.splitext(fname)
        stem_l = stem.lower()
        fname_l = fname.lower()

        # matching tier
        exact_filename = (fname_l == s) or (fname_l == f"{s_noext}{ext.lower()}")
        exact_stem     = (stem_l == s_noext)
        startswith     = stem_l.startswith(s_noext)
        contains       = (s_noext in stem_l)

        if exact_filename:
            tier = 0
        elif exact_stem:
            tier = 1
        elif startswith:
            tier = 2
        elif contains:
            tier = 3
        else:
            continue  # no match

        # plain vs suffixed (prefer plain)
        # plain = exactly the search string OR startswith but next char is not a separator
        suffix_part = stem_l[len(s_noext):] if stem_l.startswith(s_noext) else ""
        is_plain = (stem_l == s_noext) or (suffix_part == "")
        # penalize common suffixes slightly (seg/pose/cls/det)
        common_suffix = any(suffix_part.startswith(sep + suf) for sep in ("-", "_") for suf in ("seg", "pose", "cls", "det"))

        # score tuple: lower is better
        score = (
            tier,
            0 if is_plain else 1,
            0 if not common_suffix else 1,
            len(fname_l),          # shorter name preferred
            fname_l,               # alphabetical
        )
        candidates.append((score, os.path.join(models_folder, fname)))

    if not candidates:
        tried = ", ".join(files[:10]) + ("..." if len(files) > 10 else "")
        raise FileNotFoundError(f"❌ No model matched '{search_name}' in {models_folder}. Files seen: {tried}")

    candidates.sort(key=lambda x: x[0])
    if return_all:
        return [p for _, p in candidates]

    best = candidates[0][1]
    print(f"✅ Found model: {best}")
    return best


def load_datasets(json_path: str | Path) -> List[Dict[str, Any]]:
    p = Path(json_path).expanduser().resolve()
    if not p.is_file():
        raise FileNotFoundError(f"datasets.json not found at: {p}")
    with p.open("r", encoding="utf-8") as f:
        data = json.load(f)
    ds = data.get("datasets")
    if not isinstance(ds, list):
        raise ValueError("JSON must contain top-level key 'datasets' as a list.")
    return ds

def print_datasets(datasets: List[Dict[str, Any]]) -> None:
    for d in sorted(datasets, key=lambda x: x.get("id", 0)):
        did  = d.get("id", "?")
        name = d.get("name", "Unnamed")
        urls = d.get("urls", [])
        print(f"[{did:>2}] {name}")
        for u in urls or ["(no URLs)"]:
            print(f"     - {u}")
        print()

def find_datasets_json() -> Path:
    """Try common spots; fall back to a quick recursive search up to 3 levels."""
    candidates = [
        Path("datasets/datasets.json"),
        Path("../datasets/datasets.json"),
        Path("../../datasets/datasets.json"),
    ]
    for c in candidates:
        if c.is_file():
            return c.resolve()
    # last resort: look for any 'datasets.json' nearby (bounded search)
    for up in [Path("."), Path(".."), Path("../.."), Path("../../..")]:
        for m in up.rglob("datasets.json"):
            if m.name == "datasets.json":
                return m.resolve()
    raise FileNotFoundError("Couldn't locate datasets.json. Checked common paths and nearby folders.")
