!dir
%load_ext autoreload
%autoreload 2

import os, sys
from ultralytics import YOLO
sys.path.append(os.path.abspath("../util_functions"))
from util_helper_functions import util_find_model

# Ensure weight exists, download if missing
model_path = util_find_model("yolo11n.pt")

# Load model
model = YOLO(model_path)

# Run inference
results = model("../util_test_images/Banana-Single.jpg")
results[0].show()

